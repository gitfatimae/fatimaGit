const express = require("express");

//=> see 'remaks.txt' file to see how we set the variable 'PORT_ONE'
//require('dotenv').config();
//console.log(process.env.PORT_ONE);

const app = express();
/*
 process.env.PORT_ONE is accessing the value of the environment variable named PORT_ONE. 
 The || operator is the logical OR operator. It allows you to provide a default value if 
 the environment variable is not defined.
*/
const PORT = 5000;
const mongoose = require("mongoose");
const Produit = require("./Produit");
app.use(express.json());
//Connection à la base de données MongoDB « produitServiceDB »
//(Mongoose créera la base de données s'il ne le trouve pas)
/*
When strictQuery is set to true, Mongoose will enforce strict validation for query conditions. 
It means that Mongoose will validate the properties and values used in query conditions 
against the schema defined for the corresponding model.
*/
mongoose.set('strictQuery', true);

(async () => {
    try {
      await mongoose.connect("mongodb://db/produitServiceDB");
      console.log("produitServiceDB DB Connected");
    } catch (error) {
      console.error("Error connecting to MongoDB:", error);
    }
  })();
  
  app.post("/produit/ajouter", (req, res, next) => {
    const { nom, description, prix } = req.body;
    const newProduit = new Produit({
      nom,
      description,
      prix
    });
  
    newProduit.save()
      .then(produit => res.status(201).json(produit))
      .catch(error => res.status(400).json({ error }));
  });
  
  app.get("/produit/acheter", (req, res, next) => {
    const { ids } = req.body;
    Produit.find({ _id: { $in: ids } })
      .then(produits => res.status(201).json(produits))
      .catch(error => res.status(400).json({ error }));
  });
  
  app.listen(PORT, () => {
    console.log(`Produit-Service at ${PORT}`);
  });